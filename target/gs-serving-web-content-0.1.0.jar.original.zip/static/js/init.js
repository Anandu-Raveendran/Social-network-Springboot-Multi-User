(function($){

    $('.button-collapse').sideNav();
    $('.collapsible').collapsible();

})(jQuery)



